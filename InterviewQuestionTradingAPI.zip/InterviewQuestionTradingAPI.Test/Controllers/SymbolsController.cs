using InterviewQuestionTradingAPI.Controllers;
using Microsoft.Extensions.Logging;
using Moq;
using NUnit.Framework;

namespace InterviewQuestionTradingAPI.Test.Controllers
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void TestGet()
        {
            //Arrange

            //action

            //assert

        }
    }
}